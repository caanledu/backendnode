const express = require('express');
const app = express();
const server = require('http').Server(app);
const io = require('socket.io')(server);

app.use(express.static('public'));//Sirve estaticos de la carpeta publicos, cada que se lance una peticion http se puede traer todo lo de la carpeta públic

io.on('connection', function(socket){
    console.log('Nuevo cliente conectado');
    socket.emit('mensaje','Bienvenido!');
});//Cada se que genera una nueva cionexuion e enviaa el mensahe bienveniudo

//Enviar peticiones cuando yo quiera a todos los usuarios
setInterval(function() {
    io.emit('mensaje','HOla os escribo a todos');
}, 3000);

server.listen(8080,function(){
    console.log('Servidor iniciadio por el puerto 8080');
});
